﻿namespace Questao5.Domain.Enumerators;

public enum TipoMovimentacaoEnum 
{
    Debito = 'C',
    Credito = 'D'
}
