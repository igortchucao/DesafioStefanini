﻿using Questao5.Application.Commands;
using Questao5.Domain.Entities;

namespace Questao5.Application.Handlers
{
    public class MovimentacaoFinanceiraHandler : IHandlerAsync<MovimentacaoFinanceira, Guid>
    {
        public IGerarMovimentacaoFinanceira _command;

        public MovimentacaoFinanceiraHandler(IGerarMovimentacaoFinanceira command)
        {
            _command = command;
        }

        public async Task<Guid> ExecuteAsync(MovimentacaoFinanceira request)
        {
            _command.GerarMovimentacao(request);

            return request.IdRequisicao;
        }
    }
}
