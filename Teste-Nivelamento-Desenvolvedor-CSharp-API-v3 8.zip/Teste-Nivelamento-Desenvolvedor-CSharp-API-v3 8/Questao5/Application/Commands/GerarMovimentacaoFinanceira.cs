﻿using Questao5.Domain.Entities;
using Questao5.Infrastructure.Database.CommandStore;

namespace Questao5.Application.Commands
{
    public class GerarMovimentacaoFinanceira : IGerarMovimentacaoFinanceira
    {
        public IMovimentacaoFinanceiraRepository _repo;

        public GerarMovimentacaoFinanceira(IMovimentacaoFinanceiraRepository repo)
        {
            _repo = repo;
        }

        public void GerarMovimentacao(MovimentacaoFinanceira movimentacao)
        {
            _repo.InsertMovimentacaoFinanceira(movimentacao);
        }
    }
}
