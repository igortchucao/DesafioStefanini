using Microsoft.AspNetCore.Mvc;
using Questao5.Application.Handlers;
using Questao5.Domain.Entities;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BancoController : ControllerBase
    {
        private readonly ILogger<BancoController> _logger;
        private IHandlerAsync<MovimentacaoFinanceira, Guid> _handlerAsync;

        public BancoController(ILogger<BancoController> logger, IHandlerAsync<MovimentacaoFinanceira, Guid> handlerAsync)
        {
            _logger = logger;
            _handlerAsync = handlerAsync;
        }

        [HttpPost(Name = "PostMovimentacaoCC")]
        public Guid Post([FromBody] MovimentacaoFinanceira movimentacao)
        {
            return _handlerAsync.ExecuteAsync(movimentacao).Result;
        }
    }
}